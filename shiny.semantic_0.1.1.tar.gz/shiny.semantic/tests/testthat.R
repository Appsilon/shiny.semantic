library(testthat)
library(shiny.semantic)

test_check("shiny.semantic")
