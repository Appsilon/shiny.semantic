# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/).

## [Unreleased]
### Added
### Changed
### Fixed
### Removed

## [0.1.0] - 2016-12-05
### Added
- TODO your feature

[Unreleased]: https://github.com/Appsilon/shiny.semantic/compare/0.1.0...HEAD
[0.1.0]: https://github.com/Appsilon/shiny.semantic/compare/a4987aa4588cab0e511519b2a60f738e8fa5d01a...0.1.0
