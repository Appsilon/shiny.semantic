#!/bin/bash
R -e 'shiny::runApp(".")'

